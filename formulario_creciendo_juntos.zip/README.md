
# Formulario Creciendo Juntos

Esta aplicación web en Streamlit permite migrar el formulario extenso de Microsoft Forms a una interfaz personalizada con autenticación, lógica condicional y diseño por secciones.

## Características
- Autenticación por código de empleado y fecha de nacimiento
- Secciones dinámicas según respuestas
- Validación local (versión inicial)
- Preparado para integración con SharePoint
